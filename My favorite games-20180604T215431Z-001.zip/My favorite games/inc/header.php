<html>
<head>
	<title><?php echo $pagetitle; ?/</title>
	<link rel="stylesheet" href =" css/style.css" type= "text/css">
</head>
<body>

    <div class="header">

        <div class="wrapper">

        <h1 class="branding-title"><a href="/">my online library</a></h1>

<ul class ="nav">


	<li class="books"> <a href=" catalog.php?cat=books">books</a><li>

	<li class="movies"> <a href=" catalog.php?cat=movies">movies</a><li>

	<li class="music"> <a href=" catalog.php?cat=music">music</a><li>

	<li class="suggest"> <a href=" catalog.php?cat=suggest">suggest</a><li>
	
	</ul>
	
	</div>
	
	</div>
	</div id="connect"