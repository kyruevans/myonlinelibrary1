<?php
//Adventure
$catalog[101] = [
    "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
   

   $catalog[102] = [
     "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",

   $catalog[103] = [
     "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",

     $catalog[104] = [
     "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
    
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
];

//RPG
$catalog[201] = [
     "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
      
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
   
    $catalog[202] = [
     "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
   ]

    $catalog[203] = [
    "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
   ]

    $catalog[204] = [
    "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
   ]
];

//Multiplayer
$catalog[301] = [
   "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
    
    
$catalog[302] = [
    "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",

$catalog[303] = [
   "title" => "Beethoven: Complete Symphonies",
   "img" => "img/media/beethoven.jpg",
   "genre" => "Clasical",
   "format" => "CD",
   "year" => 2012,
   "category" => "Music",
   "artist" => "Ludwig van Beethoven"

$catalog[304] = [
    "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",

];

//Fighting
$catalog[101] = [
     "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
    
   $catalog[102] = [
     "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
       
   $catalog[103] = [
    "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
       
     $catalog[104] = [
    "title" => "God of war",
    "img" => "img/media/BOY.jpg",
   "genre" => "Action/adventure",
   "platfrom" => "PlatStation",
   "year" => 2018,
   "category" => "Single-player",
   "Developer" => "SIE Santa Monica Studio" [
       "Stan Lee",
   ],
   "publisher" => "Sony Interactive Entertainment",
    "overview" => "God of War is a third-person action-adventure game developed by Santa Monica Studio and published by Sony Interactive EntertainmentUnlike previous games, which were loosely based on Greek mythology, this game is loosely based on Norse mythology Kratos and his young son Atreus journey to fulfill his mothers promise and spread her ashes at the highest peak of the nine realms.",
];
