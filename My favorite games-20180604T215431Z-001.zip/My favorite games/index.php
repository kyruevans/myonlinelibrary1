<?php
include("inc/data.php");
include("inc/functions.php");

$pagetitle = "My Favorite Games";
$section = null;

include("inc/header>php"); ?>
		<div class="section catlog random">

		   <div class="wrapper">

			<h2>Weclome to the velevet room</h2>

		<ul class="iteams">
			<?php
			$random = array_rand($catalog,4);
			foreach ($random as $id) {
				echo get_iteam_html($id,$catalog[$id];
			}

			?>

			</ul>

		   </div>

		  </div>

	<?php include("inc/footer.php"); ?>
